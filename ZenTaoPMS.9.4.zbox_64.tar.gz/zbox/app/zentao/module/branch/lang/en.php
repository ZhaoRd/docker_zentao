<?php
$lang->branch->common = 'Branch';
$lang->branch->manage = 'Manage a Branch';
$lang->branch->sort   = 'Sort';
$lang->branch->delete = 'Delete Branch';

$lang->branch->manageTitle = '%s Management';
$lang->branch->all         = 'All';

$lang->branch->confirmDelete = 'Do you want to delete this @branch@?';
$lang->branch->canNotDelete  = 'There is data in @branch@. It cannot be deleted.';
