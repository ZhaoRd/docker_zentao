<?php
$config->datatable->moduleAlias['product']  = 'story';
$config->datatable->moduleAlias['project']  = 'task';
$config->datatable->moduleAlias['testtask'] = 'testcase';
